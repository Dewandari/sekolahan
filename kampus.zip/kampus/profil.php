<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>visi</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <link rel="stylesheet" type="text/css" href="
https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css">
</head>
<body>

  <!-- header -->
  <div class="medsos">
    <div class="container">
      <ul>
        <li><a href=""><i class="fab fa-facebook"></i></a></li>
        <li><a href=""><i class="fab fa-youtube"></i></a></li>
        <li><a href=""><i class="fab fa-instagram"></i> </a></li>
      </ul>
    </div>
  </div>
  <header>
    <div class="container">
      <h1>UNIVERSITAS SAHID SURAKARTA</h1>
      <ul>
        <li><a href="">LOGIN</a></li>
        <li><a href="guru.php">DOSEN</a></li>
        <li><a href="informasi.php">INFORMASI</a></li>
        <li><a href="kegiatan.php">KEGIATAN</a></li>
        <li><a href="jurusan.php">PROGRAM STUDI</a></li>
        <li class="active"><a href="profil.php">PROFIL</a></li>
        <li><a href="index.php">HOME</a></li>
      </ul>c
    </div>
  </header>

  <section class="about" style="margin-left: 40px;">
    <div class="container" >
      <img src="gambar/g.jpg" width="75%" style="margin-left: 12%;">
      <br>
      <br>
      <h3>VISI</h3>
      <br>
      <p>Menjadi pengembang IPTEKS, menghasilkan lulusan  Unggul , Berkarakter dan Berjiwa Kewirausahaan yang  berdaya saing di tingkat Nasional dan Internasional.</p>
      <br>
      <br>
      <h3>MISI</h3>
      <br>
      <li>Menyelenggarakan pendidikan dan pengajaran yang menghasilkan lulusan Unggul, Cerdas, dan Berkarakter, Berjiwa Wirausaha yang mampu bersaing di tingkat Nasional dan Internasional.</li>
      <li>Menyelenggarakan riset sesuai kebijakan riset Universitas yang Berjiwa Kewirausahaan dalam rangka pengembangan IPTEKS.</li>
      <li>Menyelenggarakan pengabdian kepada masyarakat dengan menyesuaikan kebijakan Pemerintah, Pemerintah Daerah, Kabupaten/Kota.</li>
      <li>Mewujudkan atsmofir akademik yang kondusif.</li>
      <li>Menjalin terwujudnya jejaring kerjasama bersama stakeholders dengan prinsip saling mnguntungkan masing-masing pihak baik di dalam negeri maupun di luar negeri.</li>
      <br>
      <br>
      <h3>TUJUAN UNIVERSITAS SAHID SURAKARTA</h3>
      <br>
      <li>Menghasilkan lulusan yang profesional sesuai kebutuhan pasar kerja, pemerintah, dan bermanfaat bagi masyarakat, yang dicirikan oleh:</li>
      <li>Menguasai ilmu pengetahuan, teknologi, dan seni yang berjiwa kewirausahaan.</li>
      <li>Memiliki sifat terbuka dan tanggap terhadap perkembangan ilmu pengetahuan, teknologi, dan seni serta lingkungan global.</li>
      <li>Memiliki kemampuan berkomunikasi dalam pendidikan.</li>
      <li>Karakter yang mempunyai jiwa kepemimpinan yang mampu bekerja secara mandiri atau bekerja sama dalam tim.</li>
      <li>Inovatif, kreatif dan bertanggung jawab.</li>
      <li>Menghasilkan karya ilmu pengetahuan, teknologi, dan seni yang berjiwa kewirausahaan sesuai kebutuhan pasar kerja, mendukung program pemerintah, dan bermanfaat bagi masyarakat.</li>
      <br>
      <br>
      <h3>SASARAN UNIVERSITAS SAHID SURAKARTA</h3>
      <br>
      <p>Menjadi universitas unggul di Jawa Tengah yang berkualitas dan berjiwa kewirausahaan.</p>
    </div>
  </section>

<!-- footer -->
  <footer>
    <div class="container">
      <small> Copyright &copy; 2021 - SR.Dewandari.</small>
   </div>
  </footer>
</body>
</html>