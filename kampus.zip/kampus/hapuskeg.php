<?php 
require 'function.php';

$id = $_GET["id"];

if( hapuskeg($id) > 0 ){
	echo "
			<script>
				alert('Data Berhasil DiHapus!');
				document.location.href='kegiatan2.php';
			</script>
		";
} else {
	echo "
			<script>
				alert('Data Gagal DiHapus!');
				document.location.href='kegiatan2.php';
			</script>
		";
}

 ?>
