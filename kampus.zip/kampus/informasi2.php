<?php
require 'function.php';
$informasi = informasi ("SELECT * FROM informasi");

if(isset($_POST["cari"]) ) {
  $informasi = cari($_POST["keyword"]);
}

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ubah data</title>
  <link rel="stylesheet" type="text/css" href="informasi.css">
  <link rel="stylesheet" type="text/css" href="
https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css">
</head>
<body>

  <!-- header -->
  <div class="medsos">
    <div class="container">
      <ul>
        <li><a href=""><i class="fab fa-facebook"></i></a></li>
        <li><a href=""><i class="fab fa-youtube"></i></a></li>
        <li><a href=""><i class="fab fa-instagram"></i> </a></li>
      </ul>
    </div>
  </div>
  <header>
    <div class="container">
      <h1>UNIVERSITAS SAHID SURAKARTA</h1>
      <ul>
        <li><a href="index.php">LOGOUT</a></li>
        <li><a href="guru2.php">DOSEN</a></li>
        <li class="active"><a href="informasi2.php">INFORMASI</a></li>
        <li><a href="kegiatan2.php">KEGIATAN</a></li>
      </ul>
    </div>
  </header>

  <h1>Daftar Informasi</h1>
  <a href="tambah.php">Tambah Data Informasi</a>
  <br><br>


<form action="" method="post">
  <input type="text" name="keyword" size="30" autofocus autocomplete="off">
  <button type="submit" name="cari">Cari!</button>

</form>
<br>
 <table border="1" cellpadding="10" cellspacing="0">
  <tr>
    <th>No</th>
    <th>Aksi</th>
    <th>Judul Informasi</th>
    <th>Isi Informasi</th>
    <th>Author</th>
    <th>Tanggal Pembuatan</th>
    <th>Tanggal Diubah</th>
  </tr>

  <?php $i = 1; ?>
  <?php foreach ($informasi as $lama) : ?>
  <tr>
    <td><?= $i; ?></td>
    <td>
      <a href="ubah.php?id=<?= $lama['id']; ?>">ubah</a> |
      <a href="hapus.php?id=<?= $lama['id']; ?>" onclick="return confirm('yakin?');">hapus</a>
    </td>
    <td><?= $lama["judul_informasi"]; ?></td>
    <td><?= $lama["isi_informasi"]; ?></td>
    <td><?= $lama["author"]; ?></td>
    <td><?= $lama["created_date"]; ?></td>
    <td><?= $lama["update_date"]; ?></td>
    </td>
  </tr>
    <?php $i++; ?>
  <?php endforeach; ?>

 </table>