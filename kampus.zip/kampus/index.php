<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>kampus</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <link rel="stylesheet" type="text/css" href="
https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css">
</head>
<body>

  <!-- header -->
  <div class="medsos">
    <div class="container">
      <ul>
        <li><a href=""><i class="fab fa-facebook"></i></a></li>
        <li><a href=""><i class="fab fa-youtube"></i></a></li>
        <li><a href=""><i class="fab fa-instagram"></i> </a></li>
      </ul>
    </div>
  </div>
  <header>
    <div class="container">
      <h1>UNIVERSITAS SAHID SURAKARTA</h1>
      <ul>
        <li><a href="">LOGIN</a></li>
        <li><a href="guru.php">DOSEN</a></li>
        <li><a href="informasi.php">INFORMASI</a></li>
        <li><a href="kegiatan.php">KEGIATAN</a></li>
        <li><a href="jurusan.php">PROGRAM STUDI</a></li>
        <li><a href="profil.php">PROFIL</a></li>
        <li class="active"><a href="index.php">HOME</a></li>
      </ul>
    </div>
  </header>

  <!-- banner -->
  <section class="banner">
    <h2>SELAMAT DATANG DI UNIVERSITAS SAHID SURAKARTA</h2> 
  </section>


  <!-- about -->
  <section class="about">
    <div class="container">
      <h3>Informasi Beasiswa UKT SPP</h3>
      <p>Salam Mahasiswa ‼️

Buat temen-temen mahasiswa Universitas Sahid Surakarta, ada kabar gembira nih buat kalian 📢

Temen-temen mahasiswa aktif bisa mendaftarkan diri untuk beasiswa UKT SPP lho 🙌

🔗 https://forms.gle/2nFJh2hPKjfQJofT6

‼️ Syarat
<li>1 Mhs aktif minimal semester 3.</li>
<li>2 IPK minimal 3.00</li>
<li>3 maksimal smt 7</li>
<li>4 aktif dalam kegiatan organisasi kemahasiswaan</li>

Silakan mendaftar paling lambat tanggal 22 September 2021 pukul 13:00 WIB</p>
      <br>
      <button>Daftar Sekarang</button>
    </div>
  </section>

<!-- footer -->
  <footer>
    <div class="container">
      <small> Copyright &copy; 2021 - SR.Dewandari.</small>
   </div>
  </footer>
</body>
</html>