<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>kampus</title>
  <link rel="stylesheet" type="text/css" href="juurusan.css">
  <link rel="stylesheet" type="text/css" href="
https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css">
</head>
<body>

  <!-- header -->
  <div class="medsos">
    <div class="container">
      <ul>
        <li><a href=""><i class="fab fa-facebook"></i></a></li>
        <li><a href=""><i class="fab fa-youtube"></i></a></li>
        <li><a href=""><i class="fab fa-instagram"></i> </a></li>
      </ul>
    </div>
  </div>
  <header>
    <div class="container">
      <h1>UNIVERSITAS SAHID SURAKARTA</h1>
      <ul>
        <li><a href="">LOGIN</a></li>
        <li><a href="guru.php">DOSEN</a></li>
        <li><a href="informasi.php">INFORMASI</a></li>
        <li><a href="kegiatan.php">KEGIATAN</a></li>
        <li class="active"><a href="jurusan.php">PROGRAM STUDI</a></li>
        <li><a href="profil.php">PROFIL</a></li>
        <li><a href="index.php">HOME</a></li>
      </ul>
    </div>
  </header>

 <div class="studi">
    <nav>
        <li><img src="gambar/ab2.png" width="15%"><br>
          <h4>ADMINISTRASI BISNIS</h4><br>
          <p>Administrasi bisnis merupakan salah satu program studi dalam Fakultas Sosial Humaniora dan Seni Universitas Sahid Surakarta. Dengan tujuan untuk mencetak para lulusan menjadi seorang entrepreneur (perintis dan pemilik usaha), adbispreneur/intrapreneur (seorang professional dengan kemampuan mengelola bisnis sesuai dengan kebijakan perusahaan), peneliti, pendidik dan konsultan</p>
        </li>
        <li><img src="gambar/ikom2.png" width="15%"><br>
          <h4>ILMU KOMUNIKASI</h4><br>
          <p>Ilmu Komunikasi merupakan salah satu program studi dalam Fakultas Sosial Humaniora dan Seni Universitas Sahid Surakarta. Yang mempelajari tentang bagaimana proses penyampaian pesan secara efektif agar dapat sampai kepada sasaran yang dituju. Selain itu, jurusan Ilmu Komunikasi mempelajari komunikasi dalam berbagai tingkatan, seperti antar individu, media. Ilmu Komunikasi merupakan induk dari beberapa ilmu turunannya, seperti Public Relation, Jurnalistik, Manajemen Komunikasi, Periklanan, Marketing Communication, dan lain sebagainya.</p>
        </li>
        <li><img src="gambar/tif2.png" width="15%"><br>
          <h4>TEKNIK INFORMATIKA</h4><br>
          <p>Teknik Informatika merupakan salah satu program studi dalam Fakultas Sains dan Teknologi Informasi Universitas Sahid Surakarta. Bidang ilmu yang mempelajari bagaimana menggunakan teknologi komputer secara optimal guna menangani masalah transformasi atau pengolahan data dengan proses logika. Di Jurusan Teknik Informatika kamu akan mempelajari berbagai prinsip terkait ilmu komputer mulai dari proses perancangan, pengembangan, pengujian, hingga evaluasi sistem operasi perangkat lunak.</p>
        </li>
        <li><img src="gambar/tin2.png" width="25%"><br>
          <h4>TEKNIK INDUSTRI</h4><br>
          <p>Teknik Industri merupakan salah satu program studi dalam Fakultas Sains dan Teknologi Informasi Universitas Sahid Surakarta. Ilmu yang mempelajari bagaimana mengoptimalisasi kegiatan manusia seperti; produksi, pengelolaan dan ekonomi. Lulusan Teknik Industri nantinya bertanggungjawab atas optimalisasi praktis dari sistem produksi pabrik, proposal strategi, serta desain optimal manajemen perusahaan. Di jurusan Teknik Industri, kamu akan banyak melakukan penyelesaian masalah melalui pendekatan matematis.</p>
        </li>
        <li><img src="gambar/din2 (1).png" width="20%"><br>
          <h4>DESAIN INTERIOR</h4><br>
          <p>Desain Interior merupakan salah satu program studi dalam Fakultas Sosial Humaniora dan seni Universitas Sahid Surakarta. Ilmu yang mempelajari tentang perancangan dan perencanaan penataan suatu ruang bangunan. Beberapa hal yang perlu diperhatikan dalam kegiatan perancangan dan perencanaan itu antara lain fungsi, estetika, dan juga mempertimbangkan psikologis dan kenyamanan pengguna ruangan.</p>
        </li>
          <li><img src="gambar/dkv2.png" width="35%"><br>
            <h4>DESAIN KOMUNIKASI VISUAL</h4><br>
            <p>Desain Komunikasi Visual merupakan salah satu program studi dalam Fakultas Sosial Humaniora dan Seni Universitas Sahid Surakarta. lulusan Jurusan Desain Komunikasi Visual juga dituntut untuk dapat menghasilkan karya seni agar dapat mencapai tujuan tertentu, seperti mempengaruhi perilaku seseorang. Sebagai bagian dari cabang ilmu desain, pada jurusan ini Quipperian akan dibantu untuk bisa mengolah karya seni yang dihasilkan agar bersifat informatif, komunikatif, dan efektif.</p>
          </li>
          <li><img src="gambar/p2.png" width="30%"><br>
            <h4>PERAWAT</h4><br>
            <p>Perawat merupakan salah satu program studi dalam Fakultas Sains dan Teknologi Informasi Universitas Sahid Surakarta. Perawat setidaknya berperan sebagai care provider, manager and community leader, educator, advocate, juga researcher. Dalam menjalankan profesinya, perawat akan bekerja sama dengan dokter umum, dokter spesialis, bidan, juga tenaga kesehatan lainnya. Di rumah sakit dan klinik, perawat mengikuti petunjuk dokter untuk mengurus dan membantu pasien dalam pemeriksaan kesehatan dan perawatan medis.</p>
          </li>
          <li><img src="gambar/farm2.png" width="30%"><br>
            <h4>FARMASI</h4><br>
            <p>Farmasi merupakan salah satu program studi dalam Fakultas Sains dan Teknologi Infromasi Universitas Sahid Surakarta. Farmasi merupakan kombinasi antara ilmu kesehatan dengan ilmu kimia dan tentunya sangat diperlukan di dunia medis di jurusan Farmasi, kalian akan banyak berkutat dengan senyawa kimia untuk dikembangkan jadi bahan obat. Selain itu, kalian akan mempelajari bagaimana menggunakan obat-obatan secara efektif dalam ilmu kesehatan hingga pengobatan higienis. </p>
          </li>
          <li><img src="gambar/psi2.png" width="25%"><br>
            <h4>PSIKOLOGI</h4><br>
            <p>Psikoligi merupakan salah satu program studi dalam Fakultas Sosial Humaniora dan Seni Universitas Sahid Surakarta. Psikologi merupakan disiplin ilmu yang mempelajari mental, pikiran, dan perilaku manusia. Program studi ini juga meneliti alur pemikiran dan alasan di balik perilaku dan tindakan manusia. Ilmu psikologi ini seringkali digunakan untuk menyelesaikan masalah dalam serangkaian aktivitas manusia yang kompleks. Ilmu Psikologi sendiri terbagi menjadi beberapa bagian, diantaranya adalah Psikologi Klinis, Psikologi Perkembangan, Psikologi Industri dan Organisasi, Psikologi Pendidikan, dan Psikologi Sosial</p>
            </li>

     </nav>
  </div>

  

<!-- footer -->
  <footer>
    <div class="container">
      <small> Copyright &copy; 2021 - SR.Dewandari.</small>
   </div>
  </footer>
</body>
</html>