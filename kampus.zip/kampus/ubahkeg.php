<?php 
require 'function.php'; 

$id = $_GET['id'];
if (isset($_GET['id'])) {
	$id = $_GET['id'];
	$editkegiatan = editkegiatan($id);
	while($lama = mysqli_fetch_assoc($editkegiatan)
	){
		$id = $lama['id'];
		$judul_kegiatan = $lama['judul_kegiatan'];
		$isi_kegiatan = $lama['isi_kegiatan'];
		$author = $lama['author'];
		$created_date = $lama['created_date'];
		$update_date = $lama['update_date'];
	}
}			
	if(isset($_POST['submit'])){
		if(ubahin($_POST)>0){
			echo "
			<script>
			alert('Data Berhasil Diubah!');
			document.location.href =
				'kegiatan2.php';
			</script>
			";
		} else {
			echo "
				<script>
				alert('Data Gagal Diubah!');
				document.location.href =
					'kegiatan2.php';
				</script>
			";
		}
	
	
}
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Ubah Data Kegiatan</title>
</head>
<body>
	<h1>Ubah Data Kegiatan</h1>

	<form action="" method="post">
		<ul>
			<li>
				<input type="hidden" name="id" value="<?= $id ?>">
			</li>
			<li>
				<label for="judul_kegiatan">Judul Kegiatan : </label>
				<input type="text" name="judul_kegiatan" id="judul_kegiatan" required value="<?= $judul_kegiatan ?>">
			</li>
			<br>
			<li>
				<label for="isi_kegiatan">Isi kegiatan : </label>
				<input type="text" name="isi_kegiatan" id="isi_kegiatan" required value="<?= $isi_kegiatan ?>">
			</li>
			<br>
			<li>
				<label for="author">Author : </label>
				<input type="text" name="author" id="author" required value="<?= $author ?>">
			</li>
			<li>
				<label for="created_date">Tanggal Dibuat :</label>
				<br>
				<input type="date" name="created_date" id="created_date" readonly="" required value="<?= $created_date ?>">
			</li>
			<li>
				<label for="update_date">Tanggal Diubah : </label>
				<br>
				<input type="date" name="update_date" id="update_date" required value="<?= $update_date ?>">
			</li>
			<br>
			<li>
				<button type="submit" name="submit" id="submit" style="background-color:  #234A71; color: white; padding: 10px;">Ubah Data!</button>
			</li>

		</ul>
		

	</form>
</body>
</html>