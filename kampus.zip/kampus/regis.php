<?php 
require 'function.php';

if(isset($_POST["register"])) {

	if(registrasi($_POST)>0){
		echo "<script>
			alert('user baru berhasil ditambahkan!');
		</script>";
		header("location:login.php");
	}else{
		echo mysqli_error($conn);
	}
}

 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 </head>
 <body>
 
<form action="" method="post">
	<ul>
		<br><br><label for="username">username:</label>
		<input type="text" name="username" id="username">

		<label for="password">password:</label>
		<input type="password" name="password" id="password">

		<label for="password">konfirmasi password:</label>
		<input type="password" name="password" id="password">
		<ul>
			<p><br>Anda sudah memiliki akun? <a href="login.php">klik disini</a></p>
		</ul>
		<br>
		<label><button type="submit" name="register">Register!</button></label>
	</ul>
	

</form>

 </body>
 </html>