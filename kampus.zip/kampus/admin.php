<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ubah data</title>
  <link rel="stylesheet" type="text/css" href="informasi.css">
  <link rel="stylesheet" type="text/css" href="
https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css">
</head>
<body>

  <!-- header -->
  <div class="medsos">
    <div class="container">
      <ul>
        <li><a href=""><i class="fab fa-facebook"></i></a></li>
        <li><a href=""><i class="fab fa-youtube"></i></a></li>
        <li><a href=""><i class="fab fa-instagram"></i> </a></li>
      </ul>
    </div>
  </div>
  <header>
    <div class="container">
      <h1>UNIVERSITAS SAHID SURAKARTA</h1>
      <ul>
        <li><a href="index.php">LOGOUT</a></li>
        <li><a href="guru2.php">DOSEN</a></li>
        <li class="active"><a href="informasi2.php">INFORMASI</a></li>
        <li><a href="kegiatan2.php">KEGIATAN</a></li>
      </ul>
    </div>
  </header>
</body>