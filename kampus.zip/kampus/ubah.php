<?php 
require 'function.php'; 

$id = $_GET['id'];
if (isset($_GET['id'])) {
	$id = $_GET['id'];
	$editinformasi = editinformasi($id);
	while($lama = mysqli_fetch_assoc($editinformasi)
	){
		$id = $lama['id'];
		$judul_informasi = $lama['judul_informasi'];
		$isi_informasi = $lama['isi_informasi'];
		$author = $lama['author'];
		$created_date = $lama['created_date'];
		$update_date = $lama['update_date'];
	}
}			
	if(isset($_POST['submit'])){
		if(ubahin($_POST)>0){
			echo "
			<script>
			alert('Data Berhasil Diubah!');
			document.location.href =
				'informasi2.php';
			</script>
			";
		} else {
			echo "
				<script>
				alert('Data Gagal Diubah!');
				document.location.href =
					'informasi2.php';
				</script>
			";
		}
	
	
}
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Ubah Data Informasi</title>
</head>
<body>
	<h1>Ubah Data Informasi</h1>

	<form action="" method="post">
		<ul>
			<p>
				<input type="hidden" name="id" value="<?= $id ?>">
			</p>
			<p>
				<label for="judul_informasi">Judul Informasi : </label>
				<br>
				<input type="text" name="judul_informasi" id="judul_informasi" required value="<?= $judul_informasi ?>">
			</p>
			<p>
				<label for="isi_informasi">Isi Informasi : </label>
				<br>
				<input type="text" name="isi_informasi" id="isi_informasi" required value="<?= $isi_informasi ?>">
			</p>
			<p>
				<label for="author">Author : </label>
				<br>
				<input type="text" name="author" id="author" required value="<?= $author ?>">
			</p>
			<p>
				<label for="created_date">Tanggal Dibuat :</label>
				<br>
				<input type="date" name="created_date" id="created_date" readonly="" required value="<?= $created_date ?>">
			</p>
			<p>
				<label for="update_date">Tanggal Diubah : </label>
				<br>
				<input type="date" name="update_date" id="update_date" required value="<?= $update_date ?>">
			</p>
			<br>
			<p>
				<button type="submit" name="submit" id="submit" style="background-color:  #234A71; color: white; padding: 10px;">Ubah Data!</button>
			</p>

		</ul>
		

	</form>
</body>
</html>