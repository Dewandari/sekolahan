<?php
$conn = mysqli_connect("localhost", "root", "", "kampus");
//database
function query ($query) {
	global $conn;
	$result = mysqli_query($conn, $query);
	$rows = [];
	while( $row = mysqli_fetch_assoc($result) ) {
			$rows[] = $row;		
	}
	return $rows;
}
function informasi($informasi){
	global $conn;
	$result = mysqli_query($conn, $informasi)
	;
	$baru = [];
	while($lama = mysqli_fetch_assoc($result)
		){
		$baru[] = $lama;
	}
	return $baru;
}
function kegiatan($kegiatan){
	global $conn;
	$result = mysqli_query($conn, $kegiatan)
	;
	$baru = [];
	while($lama = mysqli_fetch_assoc($result)
		){
		$baru[] = $lama;
	}
	return $baru;
}

//tambah
function tambah($tambah){
	global $conn;
	$judul_informasi = htmlspecialchars($tambah["judul_informasi"]);
	$isi_informasi = htmlspecialchars($tambah["isi_informasi"]);
	$author = htmlspecialchars($tambah["author"]);
	$created_date = htmlspecialchars($tambah["created_date"]);
	$update_date = htmlspecialchars($tambah["update_date"]);
	$query = "INSERT INTO informasi
				VALUES 
				('', '$judul_informasi', '$isi_informasi', '$author', '$created_date', '$update_date')
					";
	mysqli_query($conn, $query);
	return mysqli_affected_rows($conn);
}

function tambahguru($tambah){
	global $conn;
	$nik = htmlspecialchars($tambah["nik"]);
	$nama = htmlspecialchars($tambah["nama"]);
	$alamat = htmlspecialchars($tambah["alamat"]);
	$mata_pelajaran = htmlspecialchars($tambah["mata_pelajaran"]);
	$query = "INSERT INTO guru
				VALUES 
				('', '$nik', '$nama', '$alamat', '$mata_pelajaran')
					";
	mysqli_query($conn, $query);
	return mysqli_affected_rows($conn);
}

function tambahkeg($tambah){
	global $conn;
	$judul_kegiatan = htmlspecialchars($tambah["judul_kegiatan"]);
	$isi_kegiatan = htmlspecialchars($tambah["isi_kegiatan"]);
	$author = htmlspecialchars($tambah["author"]);
	$created_date = htmlspecialchars($tambah["created_date"]);
	$update_date = htmlspecialchars($tambah["update_date"]);
	$query = "INSERT INTO kegiatan
				VALUES 
				('', '$judul_kegiatan', '$isi_kegiatan', '$author', '$created_date', '$update_date')
					";
	mysqli_query($conn, $query);
	return mysqli_affected_rows($conn);
}

//hapus
function hapus($id){
	global $conn;
	mysqli_query($conn, "DELETE FROM informasi WHERE id=$id");

	return mysqli_affected_rows($conn);
}

function hapuskeg($id){
	global $conn;
	mysqli_query($conn, "DELETE FROM kegiatan WHERE id=$id");

	return mysqli_affected_rows($conn);
}

function hapusguru($id){
	global $conn;
	mysqli_query($conn, "DELETE FROM guru WHERE id = $id");

	return mysqli_affected_rows($conn);
}

//ubah
function editinformasi($id){
	$query = "SELECT * FROM informasi WHERE id=$id";
	return result($query);
}

function ubahin($data){
	global $conn;
	$id=$data["id"];
	$judul_informasi = htmlspecialchars($data["judul_informasi"]);
	$isi_informasi = htmlspecialchars($data["isi_informasi"]);
	$author = htmlspecialchars($data["author"]);
	$created_date = htmlspecialchars($data["created_date"]);
	$update_date = htmlspecialchars($data["update_date"]);
	$informasi = "UPDATE informasi SET
		judul_informasi='$judul_informasi',
		isi_informasi='$isi_informasi',
		author='$author',
		created_date='$created_date',
		update_date='$update_date'
		WHERE id=$id
		";
	mysqli_query($conn, $informasi);
	return mysqli_affected_rows($conn);
}

function editguru($id){
 $query = "SELECT * FROM guru WHERE id=$id";
 return result($query);
}

function ubahguru($data){
	global $conn;
	$id=$data["id"];
	$nik = htmlspecialchars($data["nik"]);
	$nama = htmlspecialchars($data["nama"]);
	$alamat = htmlspecialchars($data["alamat"]);
	$mata_pelajaran = htmlspecialchars($data["mata_pelajaran"]);
	$guru = "UPDATE guru SET
		nik='$nik',
		nama='$nama',
		alamat='$alamat',
		mata_pelajaran='$mata_pelajaran'
		WHERE id=$id
		";
	mysqli_query($conn, $guru);
	return mysqli_affected_rows($conn);
}

function result($query){
	global $conn;
	if ($result = mysqli_query($conn,$query)) {
		return $result;
	}
}


//cari
function cari($keyword) {
	$query = "SELECT * FROM informasi
		WHERE
	judul_informasi LIKE '$keyword%' 
	";
	return query($query);
}


?>