<?php 
require 'function.php';

$id = $_GET["id"];

if( hapusguru($id) > 0 ){
	echo "
			<script>
				alert('Data Berhasil DiHapus!');
				document.location.href='guru2.php';
			</script>
		";
} else {
	echo "
			<script>
				alert('Data Gagal DiHapus!');
				document.location.href='guru2.php';
			</script>
		";
}

 ?>
