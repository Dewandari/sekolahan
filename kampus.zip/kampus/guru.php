<?php
require 'function.php';
$guru = query ("SELECT * FROM guru");
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>kampus</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <link rel="stylesheet" type="text/css" href="
https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css">
</head>
<body>

  <!-- header -->
  <div class="medsos">
    <div class="container">
      <ul>
        <li><a href=""><i class="fab fa-facebook"></i></a></li>
        <li><a href=""><i class="fab fa-youtube"></i></a></li>
        <li><a href=""><i class="fab fa-instagram"></i> </a></li>
      </ul>
    </div>
  </div>
  <header>
    <div class="container">
      <h1>UNIVERSITAS SAHID SURAKARTA</h1>
      <ul>
        <li><a href="">LOGIN</a></li>
        <li class="active"><a href="guru.php">DOSEN</a></li>
        <li><a href="">INFORMASI</a></li>
        <li><a href="">KEGIATAN</a></li>
        <li><a href="jurusan.php">PROGRAM STUDI</a></li>
        <li><a href="profil.php">PROFIL</a></li>
        <li><a href="index.php">HOME</a></li>
      </ul>
    </div>
  </header>

 <table border="1" cellpadding="10" cellspacing="0">
  <tr>
    <th>No</th>
    <th>NIP</th>
    <th>Nama</th>
    <th>Alamat</th>
    <th>Mata_Kuliah</th>
  </tr>

  <?php $i = 1; ?>
  <?php foreach ($guru as $row) : ?>
  <tr>
    <td><?= $i; ?></td>
    <td><?= $row["nik"]; ?></td>
    <td><?= $row["nama"]; ?></td>
    <td><?= $row["alamat"]; ?></td>
    <td><?= $row["mata_pelajaran"]; ?></td>
    </td>
  </tr>
    <?php $i++; ?>
  <?php endforeach; ?>

 </table>