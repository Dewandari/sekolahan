<?php 
require 'function.php';
if(isset($_POST["submit"])){

	if(tambahkeg($_POST) > 0 ) {
		echo "
			<script>
				alert('Data Berhasil Ditambahkan!');
				document.location.href='kegiatan2.php';
			</script>
		";
	}else{
		echo "<script>
				alert('Data Gagal Ditambahkan!');
				document.location.href='kegiatan2.php';
			</script>
		";
	}
	
	
}
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Tambah Data Kegiatan</title>
</head>
<body>
	<h1>Tambah Data Kegiatan</h1>

	<form action="" method="post">
		<ul>
			<li>
				<label for="judul_kegiatan">Judul Kegiatan : </label>
				<input type="text" name="judul_kegiatan" id="judul_kegiatan">
			</li>
			<li>
				<label for="isi_kegiatan">Isi Kegiatan : </label>
				<input type="text" name="isi_kegiatan" id="isi_kegiatan">
			</li>
			<li>
				<label for="author">Author : </label>
				<input type="text" name="author" id="author" required="author">
			</li>
			<li>
				<label for="created_date">Tanggal Dibuat : </label>
				<input type="date" name="created_date" id="created_date">
			</li>
			<li>
				<label for="update_date">Tanggal Diubah : </label>
				<input type="date" name="update_date" id="update_date">
			</li>
			<li>
				<button type="submit" name="submit">Tambah Data!</button>
			</li>

		</ul>
		

	</form>
</body>
</html>