<?php 
require 'function.php';
if(isset($_POST["submit"])){

	if(tambahguru($_POST) > 0 ) {
		echo "
			<script>
				alert('Data Berhasil Ditambahkan!');
				document.location.href='guru2.php';
			</script>
		";
	}else{
		echo "<script>
				alert('Data Gagal Ditambahkan!');
				document.location.href='guru2.php';
			</script>
		";
	}
	
	
}
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Tambah Data Dosen</title>
</head>
<body>
	<h1>Tambah Data Dosen</h1>

	<form action="" method="post">
		<ul>
			<p>
				<input type="hidden" name="id" value="<?= $id ?>">
			</p>
			<p>
				<label for="nik">JNik : </label>
				<input type="text" name="nik" id="nik">
			</p>
			<p>
				<label for="nama">Nama : </label>
				<input type="text" name="nama" id="nama">
			</p>
			<p>
				<label for="alamat">Alamat : </label>
				<input type="text" name="alamat" id="alamat" required="alamat">
			</p>
			<p>
				<label for="mata_pelajaran">Mata Pelajaran : </label>
				<input type="mata_pelajaran" name="mata_pelajaran" id="mata_pelajaran">
			</p>
			<p>
				<button type="submit" name="submit" id="submit" style="background-color: #234A71; color: white; padding: 10px;">Tambah Data!</button>
			</p>

		</ul>
		

	</form>
</body>
</html>