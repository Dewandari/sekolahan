<?php 
require 'function.php'; 

$id = $_GET['id'];
if (isset($_GET['id'])) {
	$id = $_GET['id'];
	$editguru = editguru($id);
	while($row = mysqli_fetch_assoc($editguru)
	){
		$id = $row['id'];
		$nik = $row['nik'];
		$nama = $row['nama'];
		$alamat = $row['alamat'];
		$mata_pelajaran= $row['mata_pelajaran'];
	}
}			
	if(isset($_POST['submit'])){
		if(ubahguru($_POST)>0){
			echo "
			<script>
			alert('Data Berhasil Diubah!');
			document.location.href =
				'guru2.php';
			</script>
			";
		} else {
			echo "
				<script>
				alert('Data Gagal Diubah!');
				document.location.href =
					'guru2.php';
				</script>
			";
		}
	
	
}
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Ubah Data Dosen</title>
</head>
<body>
	<h1>Ubah Data Dosen</h1>

	<form action="" method="post">
		<ul>
			<li>
				<input type="hidden" name="id" value="<?= $id ?>">
			</li>
			<li>
				<label for="nik">Nik : </label>
				<input type="text" name="nik" id="nik" required value="<?= $nik ?>">
			</li>
			<br>
			<li>
				<label for="nama">Nama : </label>
				<input type="text" name="nama" id="nama" required value="<?= $nama ?>">
			</li>
			<br>
			<li>
				<label for="alamat">Alamat : </label>
				<input type="text" name="alamat" id="alamat" required value="<?= $alamat ?>">
			</li>
			<li>
				<label for="mata_pelajaran">mata_pelajaran :</label>
				<br>
				<input type="text" name="mata_pelajaran" id="mata_pelajaran" required value="<?= $mata_pelajaran ?>">
			</li>
			<br>
			<li>
				<button type="submit" name="submit" id="submit" style="background-color:  #234A71; color: white; padding: 10px;">Ubah Data!</button>
			</li>

		</ul>
		

	</form>
</body>
</html>